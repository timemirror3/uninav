/*                                                     
       d8888 d8b 888888 8888888b.                
      d88888 Y8P   "88b 888   Y88b               
     d88P888        888 888    888               
    d88P 888 888    888 888   d88P               
   d88P  888 888    888 8888888P"                
  d88P   888 888    888 888 T88b                 
 d8888888888 888    88P 888  T88b                
d88P     888 888    888 888   T88b               
                  .d88P                                                                                                                    
                .d88P"                                                                                                                     
               888P"                                                                                                                       
                                                                                                                     
      .o.        o8o     oooo ooooooooo.                 
     .888.       `"'     `888 `888   `Y88.               
    .8"888.     oooo      888  888   .d88'               
   .8' `888.    `888      888  888ooo88P'                
  .88ooo8888.    888      888  888`88b.                  
 .8'     `888.   888      888  888  `88b.                
o88o     o8888o o888o .o. 88P o888o  o888o               
                      `Y888P                                                                                                                                                                                            
*/

// Basic setup for the globe using Three.js
const container = document.getElementById('container');
const parent = document.getElementById('parent');
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();

renderer.setSize(window.innerWidth, window.innerHeight);
container.appendChild(renderer.domElement);

// Create the sphere (globe) and load the texture
const sphereGeometry = new THREE.SphereGeometry(5, 50, 50);
const textureLoader = new THREE.TextureLoader();
const earthTexture = textureLoader.load('textures/earth.jpg');
const sphereMaterial = new THREE.MeshBasicMaterial({ map: earthTexture });
const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
scene.add(sphere);

// Create the clouds layer
const cloudsGeometry = new THREE.SphereGeometry(5.1, 50, 50);
const cloudsTexture = textureLoader.load('textures/clouds.jpg');
const cloudsMaterial = new THREE.MeshBasicMaterial({
    map: cloudsTexture,
    transparent: true
});
const clouds = new THREE.Mesh(cloudsGeometry, cloudsMaterial);
scene.add(clouds);

// Add ambient light
const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
scene.add(ambientLight);

// Set up controls
const controls = new THREE.OrbitControls(camera, parent);
camera.position.set(0, 0, 20);
controls.update();

// Disable panning (horizontal and vertical movement)
controls.enablePan = false;

// HTML elements for information panels
const hoverPanel = document.getElementById('hover-panel');
const hoverTitle = document.getElementById('hover-title');
const infoPanel = document.getElementById('info-panel');
const infoTitle = document.getElementById('info-title');
const infoContent = document.getElementById('info-content');

// Sample data for markers
/*
const data = [
    { lat: 37.7749, lon: -122.4194, name: 'San Francisco', info: 'A beautiful city in California.' },
    { lat: 40.7128, lon: -74.0060, name: 'New York', info: 'The largest city in the United States.' }, 
    { lat: 37.871960, lon: -122.259094, name: 'UC Berkeley', info: 'UC Berkeley, officially the University of California, Berkeley, is a renowned public research university located in Berkeley, California. Established in 1868, it is the flagship campus of the University of California system. UC Berkeley is celebrated for its rigorous academic programs, distinguished faculty, and vibrant campus life. It boasts a strong tradition of activism and innovation, contributing significantly to advancements in science, technology, and social movements. The campus is home to numerous Nobel laureates and cutting-edge research facilities, making it a leader in higher education and a hub for intellectual and cultural growth.' },
    { lat: 37.428230, lon: -122.168861, name: 'Stanford', info: 'Stanford University, officially Leland Stanford Junior University, is a prestigious private research university located in Stanford, California. Founded in 1885 by Leland and Jane Stanford, the university is known for its academic strength, wealth, proximity to Silicon Valley, and ranking as one of the world\'s top universities. Stanford offers a diverse range of undergraduate and graduate programs, and is home to numerous renowned research institutes and centers. The university has produced a wealth of successful alumni, including leaders in business, politics, and science, making significant contributions to various fields globally. Its beautiful campus, vibrant student life, and commitment to research and innovation make Stanford a leader in higher education.' }
];
*/

const data = [
    { lat: 42.3601, lon: -71.0942, name: 'MIT', info: 'The Massachusetts Institute of Technology (MIT) is a world-leading institution in research, innovation, and education, especially in science and engineering.' },
    { lat: 37.4275, lon: -122.1697, name: 'Stanford University', info: 'Stanford University is a prestigious private research university located in California, known for its academic excellence and proximity to Silicon Valley.' },
    { lat: 42.3770, lon: -71.1167, name: 'Harvard University', info: 'Harvard University, located in Cambridge, Massachusetts, is the oldest institution of higher learning in the United States and is renowned for its history, influence, and wealth.' },
    { lat: 34.1377, lon: -118.1253, name: 'Caltech', info: 'The California Institute of Technology (Caltech) is a world leader in science and engineering education and research, with a small yet highly prestigious community.' },
    { lat: 51.7548, lon: -1.2544, name: 'University of Oxford', info: 'The University of Oxford, located in the UK, is one of the world\'s oldest universities and is known for its rich history, academic rigor, and contributions to research.' },
    { lat: 52.2043, lon: 0.1149, name: 'University of Cambridge', info: 'The University of Cambridge, established in 1209, is renowned for its history of academic achievement and its place as one of the top universities in the world.' },
    { lat: 41.7897, lon: -87.6007, name: 'University of Chicago', info: 'The University of Chicago is a private research university known for its strong emphasis on intellectual inquiry and contributions to the social sciences and humanities.' },
    { lat: 51.4988, lon: -0.1749, name: 'Imperial College London', info: 'Imperial College London is a public research university focused on science, engineering, medicine, and business, with a strong reputation for cutting-edge research.' },
    { lat: 47.3769, lon: 8.5417, name: 'ETH Zurich', info: 'ETH Zurich (Swiss Federal Institute of Technology) is one of the top universities in Europe, particularly strong in science, technology, engineering, and mathematics (STEM) fields.' },
    { lat: 51.5246, lon: -0.1340, name: 'University College London (UCL)', info: 'University College London (UCL) is a leading multidisciplinary university in London, known for research across a wide range of fields including science, engineering, and the humanities.' },
    { lat: 1.2966, lon: 103.7764, name: 'National University of Singapore (NUS)', info: 'The National University of Singapore is the top university in Singapore and one of the leading institutions in Asia, with a global reputation for research and teaching excellence.' },
    { lat: 39.9522, lon: -75.1932, name: 'University of Pennsylvania', info: 'The University of Pennsylvania, an Ivy League institution, is known for its strong programs in business, law, medicine, and education, as well as for its research impact.' },
    { lat: 41.3163, lon: -72.9223, name: 'Yale University', info: 'Yale University, located in New Haven, Connecticut, is a top Ivy League university renowned for its law, arts, and humanities programs, and its historic campus.' },
    { lat: 37.8715, lon: -122.2730, name: 'UC Berkeley', info: 'UC Berkeley is the flagship campus of the University of California system and is known for its rigorous academic programs and vibrant campus life.' },
    { lat: 40.8075, lon: -73.9626, name: 'Columbia University', info: 'Columbia University, an Ivy League institution located in New York City, is known for its strong emphasis on research and academic programs across a variety of disciplines.' },
    { lat: 40.3431, lon: -74.6514, name: 'Princeton University', info: 'Princeton University, an Ivy League research university, is known for its academic excellence, small student body, and prestigious programs in the humanities and sciences.' },
    { lat: 43.6629, lon: -79.3957, name: 'University of Toronto', info: 'The University of Toronto is the leading university in Canada, recognized for its diverse programs and pioneering research across various fields.' },
    { lat: 40.0030, lon: 116.3260, name: 'Tsinghua University', info: 'Tsinghua University is one of the most prestigious universities in China, known for its strong emphasis on science, technology, and engineering education.' },
    { lat: 39.9042, lon: 116.4074, name: 'Peking University', info: 'Peking University, located in Beijing, is a top research university in China with a broad range of programs in the humanities, social sciences, and natural sciences.' },
    { lat: 35.7126, lon: 139.7614, name: 'University of Tokyo', info: 'The University of Tokyo is Japan\'s leading university, known for its academic excellence and cutting-edge research across multiple disciplines.' },
    { lat: 55.9533, lon: -3.1883, name: 'University of Edinburgh', info: 'The University of Edinburgh is a world-class institution in Scotland, known for its research and programs in the humanities, sciences, and medicine.' },
    { lat: 42.2780, lon: -83.7382, name: 'University of Michigan', info: 'The University of Michigan, located in Ann Arbor, is known for its strong research output, large alumni network, and academic programs in law, business, and engineering.' },
    { lat: 46.5191, lon: 6.5668, name: 'École Polytechnique Fédérale de Lausanne (EPFL)', info: 'EPFL is a research-intensive university located in Switzerland, known for its innovation in science, technology, and engineering.' },
    { lat: -35.2777, lon: 149.1186, name: 'Australian National University', info: 'ANU is one of Australia\'s leading universities, renowned for its strong programs in research, science, and public policy.' },
    { lat: 22.2833, lon: 114.1371, name: 'University of Hong Kong', info: 'The University of Hong Kong is one of Asia\'s top universities, with a reputation for academic excellence and research in medicine, law, and business.' }
];



// Convert latitude and longitude to 3D coordinates
function latLonToVector3(lat, lon, radius, height) {
    const phi = (90 - lat) * (Math.PI / 180);
    const theta = (lon + 180) * (Math.PI / 180);
    const x = -(radius + height) * Math.sin(phi) * Math.cos(theta);
    const y = (radius + height) * Math.cos(phi);
    const z = (radius + height) * Math.sin(phi) * Math.sin(theta);
    return new THREE.Vector3(x, y, z);
}

// Add markers to the globe
const markers = [];
data.forEach(point => {
    const { lat, lon, name, info } = point;
    const markerElement = document.createElement('div');
    markerElement.className = 'marker';
    markerElement.dataset.name = name;
    markerElement.dataset.info = info;
    container.appendChild(markerElement);

    const position = latLonToVector3(lat, lon, 5, 0);
    markers.push({ element: markerElement, position });

    // Add event listeners for interaction
    markerElement.addEventListener('click', (event) => {
        event.stopPropagation(); // Prevent click event from propagating to the container

        // Instantly hide the hover panel
        hoverPanel.style.opacity = '0';
        hoverPanel.style.transform = 'translateY(-10px)';
        setTimeout(() => {
            hoverPanel.style.display = 'none';
        }, 500); // Matches the transition duration

        // Show the info panel
        infoTitle.innerText = markerElement.dataset.name;
        infoContent.innerText = markerElement.dataset.info;
        infoPanel.style.display = 'block';
        setTimeout(() => {
            infoPanel.style.opacity = '1';
            infoPanel.style.transform = 'translateY(0)';
        }, 0);

        // Get the marker's position in screen coordinates
        const vector = position.clone().project(camera);
        const x = (vector.x * 0.5 + 0.5) * window.innerWidth;
        const y = (-vector.y * 0.5 + 0.5) * window.innerHeight;

        // Position the info panel near the marker
        infoPanel.style.left = `${x + 10}px`;
        infoPanel.style.top = `${y + 10}px`;
    });

    let hoverTimeout;
    markerElement.addEventListener('mouseover', () => {
        // Clear any existing timeout
        clearTimeout(hoverTimeout);

        hoverTitle.innerText = markerElement.dataset.name;
        hoverPanel.style.display = 'block';
        setTimeout(() => {
            hoverPanel.style.opacity = '1';
            hoverPanel.style.transform = 'translateY(0)';
        }, 0);

        // Get the marker's position in screen coordinates
        const vector = position.clone().project(camera);
        const x = (vector.x * 0.5 + 0.5) * window.innerWidth;
        const y = (-vector.y * 0.5 + 0.5) * window.innerHeight;

        // Position the hover panel near the marker
        hoverPanel.style.left = `${x + 10}px`;
        hoverPanel.style.top = `${y + 10}px`;

        // Stop the rotation speed
        targetRotationSpeed = 0;
    });

    markerElement.addEventListener('mouseout', () => {
        hoverTimeout = setTimeout(() => {
            hoverPanel.style.opacity = '0';
            hoverPanel.style.transform = 'translateY(-10px)';
            setTimeout(() => {
                hoverPanel.style.display = 'none';
            }, 500); // Matches the transition duration
            targetRotationSpeed = originalRotationSpeed; // Restore rotation speed
        }, 500); // 500ms delay for the capacitor effect
    });
});

// Variables for rotation speed
let rotationSpeed = 0.00;
const originalRotationSpeed = rotationSpeed;
let targetRotationSpeed = rotationSpeed;

// Variables for momentum effect
let isDragging = false;
let previousMousePosition = { x: 0, y: 0 };
let velocityX = 0;
const VELOCITY_THRESHOLD = 0.5;

// Smooth zoom variables
let targetZoom = camera.position.z;
let zoomDelta = 0;
let zoomSpeed = 0.1;

// Animation loop
function animate() {
    requestAnimationFrame(animate);
    controls.update();

    // Smoothly transition to the target rotation speed
    rotationSpeed += (targetRotationSpeed - rotationSpeed) * 0.05;

    sphere.rotation.y += rotationSpeed; // Rotate the globe for effect
    clouds.rotation.y += rotationSpeed; // Rotate the clouds layer at the same speed

    // Apply momentum to the rotation
    if (!isDragging) {
        if (Math.abs(velocityX) > VELOCITY_THRESHOLD) {
            sphere.rotation.y += velocityX * 0.01;

            // Apply some friction to slow down the rotation over time
            velocityX *= 0.99;
        } else {
            velocityX = 0;
        }
    }

    // Smooth zoom transition
    if (Math.abs(zoomDelta) > 0.01) {
        camera.position.z += zoomDelta * zoomSpeed;
        zoomDelta *= 0.95; // Apply easing
        if (Math.abs(zoomDelta) < 0.01) {
            zoomDelta = 0;
        }
    }

    // Constrain rotation to prevent weird tilting (disable vertical rotation)
    sphere.rotation.x = 0;

    // Adjust marker size and position based on camera distance
    const cameraDistance = camera.position.distanceTo(sphere.position);
    markers.forEach(({ element, position }) => {
        const rotatedPosition = position.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), sphere.rotation.y);
        const vector = rotatedPosition.clone().project(camera);
        const x = (vector.x * 0.5 + 0.5) * window.innerWidth;
        const y = (-vector.y * 0.5 + 0.5) * window.innerHeight;

        // Calculate the dot product to determine if the marker is behind the globe
        const cameraDirection = new THREE.Vector3();
        camera.getWorldDirection(cameraDirection);
        const markerDirection = rotatedPosition.clone().normalize();
        const dotProduct = cameraDirection.dot(markerDirection);

        // Adjust opacity based on whether the marker is behind the globe
        element.style.opacity = dotProduct > 0 ? 0.2 : 1.0; // Reversed logic

        //element.style.transform = `translate(-50%, -110%) scale(${Math.max(1, Math.min(2, Math.pow(cameraDistance / 5, 2)))})`;
        element.style.transform = `translate(-50%, -110%) scale(${Math.max(0.5, Math.min(2, 1 / (0.1 * cameraDistance + 1)))})`;
        //element.style.transform = `translate(-50%, -110%) scale(${5})`;
        element.style.left = `${x}px`;
        element.style.top = `${y}px`;
    });

    // Adjust rotation speed based on camera distance
    controls.rotateSpeed = (cameraDistance * 0.05) / 1;

    renderer.render(scene, camera);

    // Update the position of the info panel for each marker
    markers.forEach(({ element, position }) => {
        const rotatedPosition = position.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), sphere.rotation.y);
        const vector = rotatedPosition.clone().project(camera);
        const x = (vector.x * 0.5 + 0.5) * window.innerWidth;
        const y = (-vector.y * 0.5 + 0.5) * window.innerHeight;

        if (infoTitle.innerText === element.dataset.name) {
            infoPanel.style.left = `${x + 10}px`;
            infoPanel.style.top = `${y + 10}px`;
        }

        if (hoverTitle.innerText === element.dataset.name && infoPanel.style.display !== 'block') {
            hoverPanel.style.left = `${x + 10}px`;
            hoverPanel.style.top = `${y + 10}px`;
        }
    });
}
animate();

// Handle window resize
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});

// Handle mouse down events for dragging
window.addEventListener('mousedown', (event) => {
    isDragging = true;
    previousMousePosition = { x: event.clientX, y: event.clientY };
});

// Handle mouse up events for dragging
window.addEventListener('mouseup', (event) => {
    isDragging = false;
});

// Handle mouse move events for dragging
window.addEventListener('mousemove', (event) => {
    if (isDragging) {
        const deltaX = event.clientX - previousMousePosition.x;

        velocityX = deltaX * 0.1; // Adjust the sensitivity as needed

        previousMousePosition = { x: event.clientX, y: event.clientY };
    }
});

// Handle smooth zoom
window.addEventListener('wheel', (event) => {
    event.preventDefault();

    const delta = Math.sign(event.deltaY);
    zoomDelta += delta * 0.5; // Accumulate zoomDelta for smoother effect

    zooming = true;
}, { passive: false });

// Hide info panel when clicking outside of it
window.addEventListener('click', (event) => {
    if (!event.target.closest('.marker') && !event.target.closest('#info-panel')) {
        infoPanel.style.opacity = '0';
        infoPanel.style.transform = 'translateY(-10px)';
        setTimeout(() => {
            infoPanel.style.display = 'none';
        }, 500); // Matches the transition duration
    }
});

